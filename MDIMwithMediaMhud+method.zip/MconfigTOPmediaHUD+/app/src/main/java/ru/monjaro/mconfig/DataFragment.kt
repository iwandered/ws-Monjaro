package ru.monjaro.mconfig

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import ru.monjaro.mconfig.databinding.DataFragmentBinding

class DataFragment : Fragment() {

    private var _binding: DataFragmentBinding? = null
    private val binding get() = _binding!!

    // 各个模块的处理器
    private lateinit var basicDataHandler: BasicDataHandler
    private lateinit var climateSeatHandler: ClimateSeatHandler
    private var mediaInfo: MediaInfo? = null

    // MConfigManager 实例
    private var mConfigManager: MConfigManager? = null

    // 用于延迟检查的Handler
    private val refreshHandler = Handler(Looper.getMainLooper())
    private var refreshRunnable: Runnable? = null

    // 移除 mediaRefreshRunnable，广播模式不需要轮询

    // ==================== 生命周期方法 ====================
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DataFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d("DataFragment", "视图已创建")

        // 初始化各个处理器
        initializeHandlers()

        // 启动基本数据处理器（包含时间更新和转向灯）
        basicDataHandler.start()

        // 初始化媒体信息处理器（立即开始）
        initializeMediaInfo()

        // 初始化 MConfigManager
        initializeMConfigManager()

        // 设置延迟刷新，确保UI完全加载
        setupDelayedRefresh()
    }

    override fun onResume() {
        super.onResume()
        Log.d("DataFragment", "Fragment恢复")

        // 确保显示是最新的
        binding.root.invalidate()
        binding.root.requestLayout()

        // 媒体信息通过广播自动更新，无需手动触发
        // mediaInfo?.triggerImmediateRefresh()

        // 移除旧服务的调用
        // MediaNotificationListenerService.triggerImmediateCheck()
    }

    override fun onPause() {
        super.onPause()
        Log.d("DataFragment", "Fragment暂停")
        stopDelayedRefresh()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        cleanupResources()
    }

    // ==================== 初始化方法 ====================
    private fun initializeHandlers() {
        // 初始化各个处理器
        basicDataHandler = BasicDataHandler(binding, this)
        climateSeatHandler = ClimateSeatHandler(binding)

        // 初始化显示
        climateSeatHandler.initializeDisplay()
    }

    private fun initializeMediaInfo() {
        try {
            // 传入 mediaInfoContainer 以便控制显隐
            mediaInfo = MediaInfo(
                requireContext(),
                binding.mediaInfoContainer, // 需要在xml中确保此ID存在
                binding.tvMediaArtist,
                binding.tvMediaTitle
            )
            mediaInfo?.start()
            Log.d("DataFragment", "媒体信息处理器初始化完成 (Broadcast模式)")
        } catch (e: Exception) {
            Log.e("DataFragment", "初始化媒体信息处理器失败", e)
        }
    }

    private fun initializeMConfigManager() {
        // 创建或获取 MConfigManager 实例并传入 Handler
        mConfigManager = MConfigManager(requireContext(), dataHandler)
    }

    private fun setupDelayedRefresh() {
        // 取消之前的刷新任务
        stopDelayedRefresh()

        refreshRunnable = object : Runnable {
            override fun run() {
                Log.d("DataFragment", "执行延迟刷新 (UI布局)")
                // 可以在这里执行一些布局相关的重绘，如果需要的话
                binding.root.requestLayout()
            }
        }

        // 延迟200ms后执行
        refreshHandler.postDelayed(refreshRunnable!!, 200)
    }

    private fun stopDelayedRefresh() {
        refreshRunnable?.let {
            refreshHandler.removeCallbacks(it)
            refreshRunnable = null
        }
    }

    // ==================== 消息处理器 ====================
    private val dataHandler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 根据消息类型分发给不同的处理器
            when (msg.what) {
                // 基本数据（包括时间、里程、车速、转速、温度、油量、机油、档位等）
                in arrayOf(
                    IdNames.ODOMETER,
                    IdNames.IGNITION_STATE,
                    IdNames.CAR_SPEED,
                    IdNames.SENSOR_RPM,
                    IdNames.AMBIENT_TEMPERATURE,
                    IdNames.INT_TEMPERATURE,
                    IdNames.FUEL_LEVEL,
                    IdNames.SENSOR_OIL_LEVEL,
                    IdNames.SENSOR_TYPE_GEAR,
                    IdNames.SEAT_OCCUPATION_STATUS_PASSENGER,
                ) -> basicDataHandler.handleMessage(msg)

                // 转向灯数据
                in arrayOf(
                    IdNames.LIGHT_LEFT_TURN,
                    IdNames.LIGHT_RIGHT_TURN,
                    IdNames.LIGHT_HAZARD_FLASHERS
                ) -> basicDataHandler.handleMessage(msg)

                // 胎压胎温数据
                in arrayOf(
                    IdNames.TIRE_PRESSURE_FL,
                    IdNames.TIRE_PRESSURE_FR,
                    IdNames.TIRE_PRESSURE_RL,
                    IdNames.TIRE_PRESSURE_RR,
                    IdNames.TIRE_TEMP_FL,
                    IdNames.TIRE_TEMP_FR,
                    IdNames.TIRE_TEMP_RL,
                    IdNames.TIRE_TEMP_RR
                ) -> basicDataHandler.handleMessage(msg)

                // 油耗数据 - 处理瞬时油耗和单次点火平均油耗
                IdNames.INSTANT_FUEL_CONSUMPTION -> basicDataHandler.handleMessage(msg)
                IdNames.SENSOR_AVG_FUEL_CONSUMPTION -> basicDataHandler.handleMessage(msg)

                // 空调和座椅系统
                in arrayOf(
                    IdNames.HVAC_FUNC_FAN_SPEED,
                    IdNames.HVAC_FUNC_AUTO_FAN_SETTING,
                    IdNames.HVAC_FUNC_AUTO,
                    IdNames.HVAC_FUNC_BLOWING_MODE,
                    IdNames.HVAC_FUNC_CIRCULATION,
                    IdNames.HVAC_FUNC_AC,
                    IdNames.SEAT_HEATING_DRIVER,
                    IdNames.SEAT_HEATING_PASSENGER,
                    IdNames.SEAT_VENTILATION_DRIVER,
                    IdNames.SEAT_VENTILATION_PASSENGER
                ) -> climateSeatHandler.handleMessage(msg)

                else -> {
                    // 减少日志：只记录未处理的消息类型
                }
            }
        }
    }

    // ==================== 资源清理 ====================
    private fun cleanupResources() {
        Log.d("DataFragment", "开始清理资源")

        // 停止延迟刷新
        stopDelayedRefresh()

        // 停止媒体信息处理器
        mediaInfo?.stop()
        mediaInfo = null

        // 停止基本数据处理器（包含时间更新和转向灯）
        basicDataHandler.stop()

        // 清理ClimateSeatHandler
        climateSeatHandler.cleanup()

        // 清理 MConfigManager
        mConfigManager?.destroy()
        mConfigManager = null

        // 清理Handler
        dataHandler.removeCallbacksAndMessages(null)
        refreshHandler.removeCallbacksAndMessages(null)

        _binding = null
        Log.d("DataFragment", "资源清理完成")
    }

    // ==================== 公共方法 ====================
    fun getHandler(): Handler {
        return dataHandler
    }

    fun refreshMediaInfo() {
        // 兼容保留
        mediaInfo?.triggerImmediateRefresh()
    }
}